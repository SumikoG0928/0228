#pragma once
#include "ConvexHull2d.h"
#include <memory>

/**
 * Cross product of 2 2d vectors. p1 x p2
 */
int crossProduct(const Point2d& p1, const Point2d& p2) noexcept {
	return p1.getY() * p2.getX() - p1.getX() * p2.getY();
}

/**
 * Determine the relative direction of p w.r.t p1p2.
 * 1 is above
 * -1 is below
 * 0 is on the line
 */
int determinDirection(const Point2d& p1, const Point2d& p2, const Point2d& p) noexcept {
	auto p1_p = p - p1;
	auto p1_p2 = p2 - p1;
	auto val = crossProduct(p1_p, p1_p2);
	if (val > 0) { return 1; }
	if (val < 0) { return -1; }
	return 0;
}

/**
 * Get the abs of cross product, can be used to determine the distance as p1 p2 has fixed length in comparision.
 */
size_t dist(const Point2d& p1, const Point2d& p2, const Point2d& p) noexcept {
	auto p1_p = p - p1;
	auto p1_p2 = p2 - p1;
	return std::abs(crossProduct(p1_p, p1_p2));
}

void quickHull(const std::vector<Point2d>& inputs, const Point2d& p1, const Point2d& p2, int direction, std::vector<Point>& convex_hull) {
	int idx = -1;
	size_t max_dist = 0;
	// find the point has the max distance for the current line.
	for (int i = 0; i < inputs.size(); ++i) {
		const auto& point = inputs[i];
		auto len = dist(p1, p2, point);
		if (determinDirection(p1, p2, point) == direction && len > max_dist) {
			idx = i;
			max_dist = len;
		}
	}
	// if null is found, add p1 p2 to the result
	if (idx == -1) {
		convex_hull.push_back(p1);
		convex_hull.push_back(p2);
		return;
	}
	quickHull(inputs, inputs[idx], p1, -determinDirection(inputs[idx], p1, p2), convex_hull);
	quickHull(inputs, inputs[idx], p2, -determinDirection(inputs[idx], p2, p1), convex_hull);
}

// Build a convex hull using quick hull
std::shared_ptr<ConvexHull> ConvexHullBuilder(const std::vector<Point2d>& points) {
	//2d convex hull has at least three points
	if (points.size() < 3) throw std::invalid_argument("size of input is too small");
	std::vector<Point> convex_points;
	auto max_point = &points[0];
	auto min_point = &points[0];
	for (const auto& point : points) {
		if (point.getX() < min_point->getX()) { min_point = &point; }
		if (point.getX() > max_point->getX()) { max_point = &point; }
	}
	quickHull(points, *min_point, *max_point, 1, convex_points);
	quickHull(points, *min_point, *max_point, -1, convex_points);
	return std::make_shared<ConvexHull>(ConvexHull2d(std::move(convex_points)));
}