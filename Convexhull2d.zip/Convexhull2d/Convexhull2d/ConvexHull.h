#pragma once
#include <vector>
#include "Point.h"
class ConvexHull {
public:
	explicit ConvexHull(std::vector<Point>& convex_hull) : convex_hull_(convex_hull) {}
	explicit ConvexHull(std::vector<Point>&& convex_hull) : convex_hull_(std::move(convex_hull)) {}
	std::vector<Point> getConvexHull() const noexcept { return convex_hull_; }
	// virtual bool detectInConvex(const Point&) = 0;//if want to check uncomment
	virtual void convexHullPrinter() const noexcept = 0;
protected:
	const std::vector<Point> convex_hull_;
};