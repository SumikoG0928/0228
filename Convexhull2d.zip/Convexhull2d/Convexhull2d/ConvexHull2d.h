#pragma once
#include "ConvexHull.h"
#include "Point2d.h"

class ConvexHull2d : public ConvexHull {
public:
	explicit ConvexHull2d(std::vector<Point>& convex_hull) : ConvexHull(convex_hull) {}
	explicit ConvexHull2d(std::vector<Point>&& convex_hull) : ConvexHull(std::move(convex_hull)) {}
	//bool detectInConvex(const Point& point) override;
	void convexHullPrinter() const noexcept override {
		std::cout << "==== 2d convex hull ====" << std::endl;
		for (auto const& point : convex_hull_) {
			point.pointPrinter();
		}
	}
};