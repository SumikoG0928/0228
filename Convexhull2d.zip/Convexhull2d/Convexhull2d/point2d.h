#pragma once
#include "Point.h"
#include <iostream>

class Point2d : public Point {
public:
	Point2d() {}
	explicit Point2d(int x, int y) : x_(x), y_(y) {}
	int getX() const noexcept { return x_; }
	int getY() const noexcept { return y_; }
	void pointPrinter() const noexcept override{
		std::cout << getX() << ", " << getY() << std::endl;
	}
	Point2d operator+(const Point2d& rhs) const noexcept {
  		//return Point2d{ rhs.getX() + x_, rhs.getY + y_ };
		return Point2d{};
	}
	Point2d operator-(const Point2d& rhs) const noexcept {
		return Point2d{}; // { x_ - rhs.getX(), y_ - rhs.getY };
	}
private:
	int x_;
	int y_;
};