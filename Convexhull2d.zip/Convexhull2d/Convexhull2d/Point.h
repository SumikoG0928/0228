#pragma once
class Point 
{
public:
	virtual void pointPrinter() const noexcept = 0;

};


